<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<head>
	<title>Ceramika</title>
	<script src="assets/jquery.min.js" type="text/javascript"></script>
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
